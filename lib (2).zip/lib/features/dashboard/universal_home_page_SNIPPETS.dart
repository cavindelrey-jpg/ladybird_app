// ─────────────────────────────────────────────────────────
// SNIPPETS — merge these into universal_home_page.dart
// (this file is NOT a standalone drop-in; it's a merge guide)
// ─────────────────────────────────────────────────────────

// Inside _UniversalHomePageState

// 1. Fix Search and Notification Buttons in _topBar
IconButton(
  icon: const Icon(Icons.search_rounded, color: C.txt2),
  onPressed: () => Navigator.of(context).push(
    MaterialPageRoute(builder: (_) => SearchPage(user: _u ?? AppUser.guest()))
  ),
),
IconButton(
  icon: const Icon(Icons.notifications_outlined, color: C.txt2),
  onPressed: () => Navigator.of(context).push(
    MaterialPageRoute(builder: (_) => NotificationsPage(userId: _u?.id ?? ''))
  ),
),

// 2. Fix Quick Access Navigation
void _openQuickAccess(BuildContext context, String label) {
  final user = _u ?? AppUser.guest();
  switch (label) {
    case 'Magazine':
      _open(context, MagazineFeedPage(user: user));
      break;
    case 'Clubs':
      _open(context, ClubsPage(user: user));
      break;
    case 'Library':
      _open(context, AcademicContentPage(user: user));
      break;
    case 'Past Questions':
      _open(context, AcademicContentPage(user: user, initialTypeFilter: ContentType.pastPaper));
      break;
    case 'Quizzes':
      _open(context, TestsSubjectPickerPage(user: user));
      break;
  }
}

// 3. Fix Hero Banner Navigation
void _openHeroSlide(BuildContext context, HeroSlide slide) {
  final user = _u ?? AppUser.guest();
  switch (slide.destination) {
    case HeroDestination.library:
      _open(context, AcademicContentPage(user: user));
      break;
    case HeroDestination.clubs:
      _open(context, ClubsPage(user: user));
      break;
    case HeroDestination.pastQuestions:
      _open(context, AcademicContentPage(user: user, initialTypeFilter: ContentType.pastPaper));
      break;
    case HeroDestination.magazine:
      _open(context, MagazineFeedPage(user: user));
      break;
    case HeroDestination.courses:
      _open(context, CoursesMarketplacePage(user: user));
      break;
    default: break;
  }
}

// 4. Fix Top Writers and Announcements Buttons
// Locate the _writersAndAnnouncementsRow and wrap titles in InkWell/GestureDetector
Expanded(
  child: _panel(
    title: 'Top Writers',
    onTap: () => _open(context, const TopWritersPage()),
    child: _topWritersContent()
  )
),
Expanded(
  child: _panel(
    title: 'Recent Announcements',
    onTap: () => _open(context, AnnouncementsPage(user: user, canPost: user.canPostAnnouncement)),
    child: _announcementsContent()
  )
),
