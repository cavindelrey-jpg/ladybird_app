// lib/features/magazine/article_reader_page.dart
// Full article render, author byline, comment thread, read counter fired
// once per view. Body renders as plain paragraphs — see the composer's
// header comment for the block-editor upgrade path.
//
// Design pass: reading text now uses AppText.body (15px / 1.65 line
// height) instead of a tight 1.7-height inline style picked ad hoc — this
// is the single biggest lever on whether reading here feels like Substack
// or a form. Whole page fades in on open rather than popping in flat.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../models/app_user.dart';
import '../../models/magazine_article.dart';
import '../../repositories/magazine_repository.dart';
import '../../repositories/notification_repository.dart';
import '../../models/app_notification.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import 'author_profile_page.dart';
import 'article_composer_page.dart';

class ArticleReaderPage extends StatefulWidget {
  final MagazineArticle article;
  final AppUser? currentUser;
  const ArticleReaderPage({super.key, required this.article, this.currentUser});

  @override
  State<ArticleReaderPage> createState() => _ArticleReaderPageState();
}

class _ArticleReaderPageState extends State<ArticleReaderPage> with SingleTickerProviderStateMixin {
  final _commentCtrl = TextEditingController();
  bool _postingComment = false;
  bool _countedRead = false;

  late final AnimationController _entryCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 420));
  late final Animation<double> _entryFade = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut);
  late final Animation<Offset> _entryRise = Tween<Offset>(
    begin: const Offset(0, 0.03), end: Offset.zero,
  ).animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic));

  @override
  void initState() {
    super.initState();
    _entryCtrl.forward();
    // Fire once per view, don't block render on it.
    if (!_countedRead) {
      _countedRead = true;
      MagazineRepository.instance.incrementReads(widget.article.id);
    }
  }

  @override
  void dispose() {
    _commentCtrl.dispose();
    _entryCtrl.dispose();
    super.dispose();
  }

  bool get _isOwnArticle => widget.currentUser?.id == widget.article.authorId;

  Future<void> _postComment() async {
    final user = widget.currentUser;
    final body = _commentCtrl.text.trim();
    if (user == null || body.isEmpty) return;
    HapticFeedback.lightImpact();
    setState(() => _postingComment = true);
    final comment = ArticleComment(
      id: '', articleId: widget.article.id,
      authorId: user.id, authorName: user.name, authorPhotoUrl: user.photoUrl,
      body: body,
    );
    await MagazineRepository.instance.postComment(comment);
    // Best-effort notify — never blocks the comment success path.
    if (widget.article.authorId != user.id) {
      NotificationRepository.instance.create(
        uid: widget.article.authorId,
        type: NotificationType.comment,
        title: 'New comment on "${widget.article.title}"',
        body: '${user.name}: $body',
        deepLinkId: widget.article.id,
      );
    }
    _commentCtrl.clear();
    if (mounted) setState(() => _postingComment = false);
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.article;
    return Scaffold(
      backgroundColor: C.bg,
      appBar: AppBar(
        backgroundColor: C.bg, elevation: 0,
        iconTheme: const IconThemeData(color: C.txt),
        actions: [
          if (_isOwnArticle)
            IconButton(
              icon: const Icon(Icons.edit_outlined, color: C.txt),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ArticleComposerPage(user: widget.currentUser!, existing: a))),
            ),
        ],
      ),
      body: FadeTransition(
        opacity: _entryFade,
        child: SlideTransition(
          position: _entryRise,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              if ((a.thumbnailUrl ?? '').isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(Rad.md),
                  child: Image.network(a.thumbnailUrl!, height: 200, width: double.infinity, fit: BoxFit.cover),
                ),
              const SizedBox(height: 20),
              Text(a.title, style: AppText.h1),
              const SizedBox(height: 16),
              Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(Rad.sm),
                  onTap: () {
                    HapticFeedback.selectionClick();
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => AuthorProfilePage(authorId: a.authorId, currentUser: widget.currentUser)));
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(children: [
                      UserAvatar(initials: a.authorName.isEmpty ? '?' : a.authorName[0].toUpperCase(),
                          radius: 18, photoUrl: a.authorPhotoUrl),
                      const SizedBox(width: 10),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(a.authorName, style: AppText.subtitle.copyWith(color: C.txt, fontSize: 13.5)),
                        Text(_formatDate(a.createdAt), style: AppText.caption),
                      ]),
                      const Spacer(),
                      Icon(Icons.visibility_outlined, size: 15, color: C.muted),
                      const SizedBox(width: 4),
                      Text('${a.readCount}', style: AppText.caption),
                    ]),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Divider(color: C.bdr2),
              const SizedBox(height: 20),
              Text(a.body, style: AppText.body),
              const SizedBox(height: 32),
              const Divider(color: C.bdr2),
              const SizedBox(height: 16),
              Text('Comments (${a.commentCount})', style: AppText.h2.copyWith(fontSize: 15)),
              const SizedBox(height: 14),
              if (widget.currentUser != null)
                Row(children: [
                  Expanded(
                    child: TextField(
                      controller: _commentCtrl,
                      style: AppText.bodySm.copyWith(color: C.txt),
                      decoration: InputDecoration(
                        hintText: 'Add a comment…',
                        filled: true, fillColor: C.surf3,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(Rad.sm), borderSide: BorderSide.none),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  _postingComment
                      ? const SizedBox(width: 40, height: 40,
                          child: Center(child: SizedBox(width: 18, height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2))))
                      : Material(
                          color: Colors.transparent,
                          shape: const CircleBorder(),
                          child: IconButton(
                            icon: const Icon(Icons.send_rounded, color: C.primary),
                            onPressed: _postComment,
                          ),
                        ),
                ])
              else
                Text('Sign in to join the discussion.', style: AppText.bodySm),
              const SizedBox(height: 16),
              StreamBuilder<List<ArticleComment>>(
                stream: MagazineRepository.instance.watchComments(a.id),
                builder: (context, snap) {
                  final comments = snap.data ?? const <ArticleComment>[];
                  if (comments.isEmpty) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Text('No comments yet — start the discussion.', style: AppText.bodySm),
                    );
                  }
                  return Column(children: comments.map((c) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      UserAvatar(initials: c.authorName.isEmpty ? '?' : c.authorName[0].toUpperCase(),
                          radius: 14, photoUrl: c.authorPhotoUrl),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Text(c.authorName, style: AppText.subtitle.copyWith(color: C.txt)),
                            const SizedBox(width: 6),
                            Text(_formatDate(c.createdAt), style: AppText.caption),
                          ]),
                          const SizedBox(height: 3),
                          Text(c.body, style: AppText.bodySm.copyWith(height: 1.4)),
                        ]),
                      ),
                    ]),
                  )).toList());
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  static const _months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  String _formatDate(DateTime dt) => '${_months[dt.month - 1]} ${dt.day}, ${dt.year}';
}
