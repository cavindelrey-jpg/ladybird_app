// lib/features/magazine/author_profile_page.dart
// A writer's article list. If viewing your own profile, drafts show too
// (with a DRAFT badge) alongside published work; viewing someone else's
// profile shows only what's published.

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/constants.dart';
import '../../models/app_user.dart';
import '../../models/institution.dart';
import '../../models/magazine_article.dart';
import '../../repositories/magazine_repository.dart';
import '../../repositories/follow_repository.dart';
import '../../repositories/institution_repository.dart';
import '../../services/analytics_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import '../../widgets/app_background.dart';
import 'article_reader_page.dart';
import 'article_composer_page.dart';

/// One-time-ish lookup of the full user profile (for bio/institution) —
/// the article-derived header fields (name/photo) already come from
/// MagazineArticle, so this only backs the extra stat fields.
Stream<AppUser?> _watchAuthorUser(String authorId) => FirebaseFirestore.instance
    .collection(AppConstants.colUsers)
    .doc(authorId)
    .snapshots()
    .map((d) => d.exists ? AppUser.fromFirestore(d.id, d.data()!) : null);

class AuthorProfilePage extends StatelessWidget {
  final String authorId;
  final AppUser? currentUser;
  const AuthorProfilePage({super.key, required this.authorId, this.currentUser});

  bool get _isOwnProfile => currentUser?.id == authorId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.bg,
      appBar: AppBar(
        backgroundColor: C.bg, elevation: 0,
        iconTheme: const IconThemeData(color: C.txt),
        title: Text(_isOwnProfile ? 'Your Articles' : 'Writer Profile', style: AppText.title),
      ),
      body: AppBackground(child: StreamBuilder<List<MagazineArticle>>(
        stream: MagazineRepository.instance.watchByAuthor(authorId),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const _AuthorSkeleton();
          }
          if (snap.hasError) {
            CrashService.instance.recordError(snap.error, snap.stackTrace,
                context: 'AuthorProfilePage.watchByAuthor($authorId)');
            return ErrorView(message: "Couldn't load this profile — ${snap.error}");
          }
          var articles = snap.data ?? const <MagazineArticle>[];
          if (!_isOwnProfile) {
            articles = articles.where((a) => a.published).toList();
          }
          if (articles.isEmpty) {
            return EmptyState(
              icon: Icons.auto_stories_outlined,
              title: _isOwnProfile ? "You haven't written anything yet" : 'No published articles yet',
              subtitle: _isOwnProfile ? 'Tap Write on the Magazine feed to start.' : null,
            );
          }
          final headerName = articles.first.authorName;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(children: [
                UserAvatar(
                  initials: headerName.isEmpty ? '?' : headerName[0].toUpperCase(),
                  radius: 26, photoUrl: articles.first.authorPhotoUrl,
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(headerName, style: AppText.h2),
                    Row(children: [
                      Text('${articles.length} article${articles.length == 1 ? '' : 's'}',
                          style: AppText.bodySm),
                      Text('  ·  ', style: AppText.bodySm),
                      StreamBuilder<int>(
                        stream: FollowRepository.instance.watchFollowerCount(authorId),
                        builder: (context, s) => Text(
                            '${s.data ?? 0} follower${(s.data ?? 0) == 1 ? '' : 's'}',
                            style: AppText.bodySm),
                      ),
                      Text('  ·  ', style: AppText.bodySm),
                      StreamBuilder<int>(
                        stream: FollowRepository.instance.watchFollowingCount(authorId),
                        builder: (context, s) => Text(
                            '${s.data ?? 0} following', style: AppText.bodySm),
                      ),
                    ]),
                  ]),
                ),
                if (!_isOwnProfile && currentUser != null)
                  _FollowButton(currentUserId: currentUser!.id, authorId: authorId),
              ]),
              StreamBuilder<AppUser?>(
                stream: _watchAuthorUser(authorId),
                builder: (context, s) {
                  final u = s.data;
                  if (u == null || (u.bio.isEmpty && u.schoolId == null)) {
                    return const SizedBox(height: 20);
                  }
                  return Padding(
                    padding: const EdgeInsets.only(top: 10, bottom: 20),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      if (u.bio.isNotEmpty)
                        Text(u.bio, style: AppText.bodySm.copyWith(height: 1.4)),
                      if (u.schoolId != null)
                        Padding(
                          padding: EdgeInsets.only(top: u.bio.isNotEmpty ? 8 : 0),
                          child: StreamBuilder<Institution?>(
                            stream: InstitutionRepository.instance.watch(u.schoolId!),
                            builder: (context, inst) {
                              final name = inst.data?.schoolName;
                              if (name == null || name.isEmpty) return const SizedBox.shrink();
                              return Row(children: [
                                const Icon(Icons.school_outlined, size: 14, color: C.muted),
                                const SizedBox(width: 4),
                                Text(name, style: AppText.caption.copyWith(fontSize: 12)),
                              ]);
                            },
                          ),
                        ),
                    ]),
                  );
                },
              ),
              ...articles.map((a) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ACard(
                  onTap: () {
                    if (a.published || _isOwnProfile) {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => ArticleReaderPage(article: a, currentUser: currentUser)));
                    }
                  },
                  child: Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(
                            child: Text(a.title, style: AppText.title.copyWith(fontSize: 14),
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                          ),
                          if (!a.published)
                            const Padding(
                              padding: EdgeInsets.only(left: 8),
                              child: StatusBadge(label: 'DRAFT', color: C.org, bg: C.orgb),
                            ),
                        ]),
                        const SizedBox(height: 6),
                        Row(children: [
                          const Icon(Icons.visibility_outlined, size: 13, color: C.muted),
                          const SizedBox(width: 3),
                          Text('${a.readCount}', style: AppText.caption),
                          const SizedBox(width: 10),
                          const Icon(Icons.mode_comment_outlined, size: 13, color: C.muted),
                          const SizedBox(width: 3),
                          Text('${a.commentCount}', style: AppText.caption),
                        ]),
                      ]),
                    ),
                    if (_isOwnProfile)
                      IconButton(
                        icon: const Icon(Icons.edit_outlined, size: 18, color: C.txt2),
                        onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => ArticleComposerPage(user: currentUser!, existing: a))),
                      ),
                  ]),
                ),
              )),
            ],
          );
        },
      )),
    );
  }
}

class _FollowButton extends StatelessWidget {
  final String currentUserId;
  final String authorId;
  const _FollowButton({required this.currentUserId, required this.authorId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<bool>(
      stream: FollowRepository.instance.watchIsFollowing(currentUserId, authorId),
      builder: (context, snap) {
        final following = snap.data ?? false;
        return SizedBox(
          height: 34,
          child: following
              ? OutlinedButton(
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    FollowRepository.instance.unfollow(currentUserId, authorId);
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: C.txt2,
                    side: const BorderSide(color: C.bdr),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                  ),
                  child: Text('Following', style: AppText.caption.copyWith(fontSize: 12, fontWeight: FontWeight.w700)),
                )
              : ElevatedButton(
                  onPressed: () {
                    HapticFeedback.mediumImpact();
                    FollowRepository.instance.follow(currentUserId, authorId);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: C.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                  ),
                  child: Text('Follow', style: AppText.caption.copyWith(
                      fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)),
                ),
        );
      },
    );
  }
}

/// Header + list skeleton matching the loaded layout's silhouette.
class _AuthorSkeleton extends StatelessWidget {
  const _AuthorSkeleton();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Row(children: [
          ShimmerCircle(size: 52),
          SizedBox(width: 14),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ShimmerLine(width: 120, height: 16),
            SizedBox(height: 6),
            ShimmerLine(width: 70, height: 12),
          ]),
        ]),
        const SizedBox(height: 20),
        for (int i = 0; i < 3; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: C.surf, borderRadius: BorderRadius.circular(Rad.md), border: Border.all(color: C.bdr)),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                ShimmerLine(height: 15),
                SizedBox(height: 10),
                ShimmerLine(width: 100, height: 12),
              ]),
            ),
          ),
      ],
    );
  }
}
