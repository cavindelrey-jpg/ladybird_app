// lib/repositories/test_repository.dart
// All reads/writes for the Testing & Quiz system: tests/{testId} and
// top-level testAttempts/{attemptId}. See models/test.dart and
// models/test_attempt.dart for the schema rationale.
//
// Grading framework:
//   - MCQ questions are graded the instant an attempt is submitted.
//   - Structured/long-form questions start ungraded and are graded via
//     gradeResponse() — today, called by a lecturer/admin from the
//     grading queue (watchPendingGradingQueue). That single method is
//     the seam a future AI grader would call into instead of a human —
//     nothing else in this repository would need to change. No AI
//     grading is wired up yet; this is a real gap, not a hidden one.
//   - XP for every graded question flows through XpRepository.awardXp
//     (capped, logged) using the rates in core/xp_rules.dart — never a
//     bespoke increment here.
//
// Honest scope note: this repository doesn't itself restrict who can
// call createTest() or gradeResponse() — that enforcement belongs in
// firestore.rules (role checks against the caller's `users/{uid}.role`),
// which hasn't been updated for the `tests`/`testAttempts` collections
// yet. UI should still gate these behind AppUser.canUploadContent /
// hasMinRole(lecturer) as a first line of defense, matching how
// AcademicContentRepository's upload flow already works.

import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/constants.dart';
import '../core/result.dart';
import '../core/xp_rules.dart';
import '../models/test.dart';
import '../models/test_attempt.dart';
import '../models/xp_transaction.dart';
import 'xp_repository.dart';

class TestRepository {
  TestRepository._();
  static final TestRepository instance = TestRepository._();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _tests =>
      _db.collection(AppConstants.colTests);
  CollectionReference<Map<String, dynamic>> get _attempts =>
      _db.collection(AppConstants.colTestAttempts);

  // ── Reading tests ────────────────────────────────────────────────────

  /// Live list of published tests for one subject. [institutionId] null
  /// means "show only the open-to-everyone tests"; pass the student's
  /// own institutionId to ALSO include their school's restricted tests
  /// (done client-side below since Firestore can't OR two `where`s on
  /// different fields in one query without a composite index per
  /// combination — acceptable at this scale; revisit if a subject
  /// regularly has hundreds of tests).
  Stream<List<Test>> watchTestsBySubject(String subject, {String? institutionId}) {
    return _tests
        .where('subject', isEqualTo: subject)
        .where('published', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) {
      final all = s.docs.map(Test.fromFirestore).toList();
      return all
          .where((t) => t.institutionId == null || t.institutionId == institutionId)
          .toList();
    });
  }

  Stream<Test?> watchTest(String testId) => _tests
      .doc(testId)
      .snapshots()
      .map((d) => d.exists ? Test.fromFirestore(d) : null);

  /// Distinct subjects that currently have at least one published test —
  /// drives the subject picker. Computed from real documents, same
  /// pattern as AcademicContentRepository.subjectsOnce(); no fixed
  /// hardcoded subject list.
  Future<List<String>> distinctSubjectsOnce() async {
    final snap = await _tests.where('published', isEqualTo: true).get();
    final subjects = snap.docs
        .map((d) => (d.data()['subject'] as String?) ?? '')
        .where((s) => s.isNotEmpty)
        .toSet()
        .toList()
      ..sort();
    return subjects;
  }

  /// Real per-subject test counts — for a subject-picker grid that shows
  /// "12 tests" instead of a bare list, without fabricating a number.
  Future<Map<String, int>> subjectTestCountsOnce() async {
    final snap = await _tests.where('published', isEqualTo: true).get();
    final counts = <String, int>{};
    for (final doc in snap.docs) {
      final subject = (doc.data()['subject'] as String?) ?? '';
      if (subject.isEmpty) continue;
      counts[subject] = (counts[subject] ?? 0) + 1;
    }
    return counts;
  }

  // ── Authoring (lecturer/admin) ───────────────────────────────────────

  Future<Result<String>> createTest(Test test) async {
    try {
      final ref = await _tests.add(test.toFirestore());
      return Success(ref.id);
    } catch (e) {
      return Failure('Failed to create test', e);
    }
  }

  Future<Result<void>> updateTest(String testId, Test test) async {
    try {
      await _tests.doc(testId).set(test.toFirestore());
      return const Success(null);
    } catch (e) {
      return Failure('Failed to update test', e);
    }
  }

  Future<Result<void>> deleteTest(String testId) async {
    try {
      await _tests.doc(testId).delete();
      return const Success(null);
    } catch (e) {
      return Failure('Failed to delete test', e);
    }
  }

  // ── Taking a test ────────────────────────────────────────────────────

  /// Submits one attempt. [rawAnswers] keys are question ids; values are
  /// an `int` (selected option index) for mcq questions or a
  /// `List<String>` (one entry per line/section) for structured/longForm
  /// questions.
  ///
  /// MCQ questions are graded and their XP awarded immediately. If the
  /// test is pure-MCQ (no manual grading needed), the completion bonus is
  /// also awarded immediately and the attempt is stored already
  /// `graded`. Otherwise the attempt is stored `submitted`, pending
  /// gradeResponse() calls for its structured/longForm questions.
  Future<Result<TestAttempt>> submitAttempt({
    required Test test,
    required String userId,
    required String userName,
    required Map<String, dynamic> rawAnswers,
  }) async {
    if (userId.isEmpty) return const Failure('Sign in to submit a test.', null);
    try {
      var totalXpFromQuestions = 0;
      final responses = <QuestionResponse>[];

      for (final q in test.questions) {
        if (q.type == QuestionType.mcq) {
          final selected = rawAnswers[q.id];
          final selectedIndex = selected is int ? selected : -1;
          final correct = selectedIndex == q.correctIndex;
          final pointsAwarded = correct ? q.points : 0;
          final xp = questionXp(
            type: q.type,
            pointsAwarded: pointsAwarded,
            maxPoints: q.points,
            difficulty: test.difficulty,
          );
          totalXpFromQuestions += xp;
          responses.add(QuestionResponse(
            questionId: q.id, type: q.type, maxPoints: q.points,
            selectedIndex: selectedIndex, pointsAwarded: pointsAwarded,
            graded: true, xpEarned: xp,
          ));
        } else {
          final raw = rawAnswers[q.id];
          final textAnswer = raw is List
              ? raw.map((e) => e.toString()).toList()
              : (raw is String ? [raw] : <String>[]);
          responses.add(QuestionResponse(
            questionId: q.id, type: q.type, maxPoints: q.points,
            textAnswer: textAnswer, graded: false,
          ));
        }
      }

      final fullyGradedNow = responses.every((r) => r.graded);
      final scorePercentSoFar = test.totalPossiblePoints <= 0
          ? 0.0
          : (responses.fold(0, (s, r) => s + (r.pointsAwarded ?? 0)) /
              test.totalPossiblePoints *
              100);
      final bonus = fullyGradedNow
          ? completionBonusXp(
              totalQuestionXpEarned: totalXpFromQuestions,
              scorePercent: scorePercentSoFar,
            )
          : 0;

      final attemptRef = _attempts.doc();
      final attempt = TestAttempt(
        id: attemptRef.id,
        testId: test.id,
        testTitle: test.title,
        subject: test.subject,
        difficulty: test.difficulty,
        userId: userId,
        userName: userName,
        responses: responses,
        totalPossiblePoints: test.totalPossiblePoints,
        status: fullyGradedNow ? AttemptStatus.graded : AttemptStatus.submitted,
        totalXpAwarded: totalXpFromQuestions + bonus,
        submittedAt: DateTime.now(),
        gradedAt: fullyGradedNow ? DateTime.now() : null,
      );
      await attemptRef.set(attempt.toFirestore());

      // Award XP for the auto-graded (mcq) portion, grouped by source so
      // the ledger shows one clean "+N XP · MCQ" entry per attempt
      // rather than one row per question.
      if (totalXpFromQuestions > 0) {
        await XpRepository.instance.awardXp(
          userId, XpSource.mcq, totalXpFromQuestions,
          refId: attemptRef.id,
        );
      }
      if (bonus > 0) {
        await XpRepository.instance.awardXp(
          userId, XpSource.testCompletion, bonus,
          refId: attemptRef.id,
        );
      }

      return Success(attempt);
    } catch (e) {
      return Failure('Failed to submit test', e);
    }
  }

  // ── Grading (lecturer/admin, or a future AI grader) ─────────────────

  /// Grades one structured/long-form response inside [attemptId]. Awards
  /// that question's XP immediately, and — if this was the LAST ungraded
  /// response in the attempt — also computes and awards the completion
  /// bonus, marking the attempt fully `graded`.
  Future<Result<void>> gradeResponse({
    required String attemptId,
    required String questionId,
    required int pointsAwarded,
    String? feedback,
  }) async {
    try {
      int xpJustAwarded = 0;
      int bonusJustAwarded = 0;
      String userId = '';

      await _db.runTransaction((tx) async {
        final snap = await tx.get(_attempts.doc(attemptId));
        if (!snap.exists) throw Exception('Attempt not found');
        final attempt = TestAttempt.fromFirestore(snap);
        userId = attempt.userId;

        final idx = attempt.responses.indexWhere((r) => r.questionId == questionId);
        if (idx == -1) throw Exception('Question not found in this attempt');
        final target = attempt.responses[idx];
        if (target.graded) throw Exception('This answer was already graded');

        final xp = questionXp(
          type: target.type,
          pointsAwarded: pointsAwarded,
          maxPoints: target.maxPoints,
          difficulty: attempt.difficulty,
        );
        xpJustAwarded = xp;

        final updatedResponses = List<QuestionResponse>.from(attempt.responses);
        updatedResponses[idx] = target.copyWith(
          pointsAwarded: pointsAwarded.clamp(0, target.maxPoints),
          graded: true,
          feedback: feedback,
          xpEarned: xp,
        );

        final nowFullyGraded = updatedResponses.every((r) => r.graded);
        var bonus = 0;
        if (nowFullyGraded) {
          final totalQuestionXp =
              updatedResponses.fold(0, (s, r) => s + r.xpEarned);
          final gradedPoints =
              updatedResponses.fold(0, (s, r) => s + (r.pointsAwarded ?? 0));
          final scorePercent = attempt.totalPossiblePoints <= 0
              ? 0.0
              : (gradedPoints / attempt.totalPossiblePoints * 100);
          bonus = completionBonusXp(
            totalQuestionXpEarned: totalQuestionXp,
            scorePercent: scorePercent,
          );
          bonusJustAwarded = bonus;
        }

        tx.update(_attempts.doc(attemptId), {
          'responses': updatedResponses.map((r) => r.toMap()).toList(),
          'status': nowFullyGraded ? AttemptStatus.graded.name : AttemptStatus.submitted.name,
          'gradedAt': nowFullyGraded ? Timestamp.fromDate(DateTime.now()) : null,
          'totalXpAwarded': FieldValue.increment(xp + bonus),
        });
      });

      if (xpJustAwarded > 0) {
        final source = await _sourceForGrading(attemptId, questionId);
        await XpRepository.instance.awardXp(
          userId, source, xpJustAwarded, refId: attemptId,
        );
      }
      if (bonusJustAwarded > 0) {
        await XpRepository.instance.awardXp(
          userId, XpSource.testCompletion, bonusJustAwarded, refId: attemptId,
        );
      }
      return const Success(null);
    } catch (e) {
      return Failure(e.toString().replaceFirst('Exception: ', ''), e);
    }
  }

  // gradeResponse doesn't have the QuestionType handy after the
  // transaction closes (it only returns primitives out of the closure by
  // design, to keep the transaction retryable/side-effect-free) — so it
  // re-derives the source from a fresh read. Simple and correct at the
  // cost of one extra read per manual grade, which is a rare, human-paced
  // action (not a hot path like awardXp's own cap check).
  Future<XpSource> _sourceForGrading(String attemptId, String questionId) async {
    final doc = await _attempts.doc(attemptId).get();
    final attempt = TestAttempt.fromFirestore(doc);
    final q = attempt.responses.firstWhere((r) => r.questionId == questionId);
    return xpSourceForQuestionType(q.type);
  }

  // ── History ──────────────────────────────────────────────────────────

  /// A user's full test history, newest first — powers the XP dashboard's
  /// "Test History" section.
  Stream<List<TestAttempt>> watchAttemptHistory(String userId, {int limit = 50}) => _attempts
      .where('userId', isEqualTo: userId)
      .orderBy('submittedAt', descending: true)
      .limit(limit)
      .snapshots()
      .map((s) => s.docs.map(TestAttempt.fromFirestore).toList());

  /// Attempts still awaiting manual grading — the lecturer/admin queue.
  /// Optionally scoped to one subject (e.g. a lecturer only grading
  /// their own subject's tests).
  Stream<List<TestAttempt>> watchPendingGradingQueue({String? subject}) {
    Query<Map<String, dynamic>> q = _attempts
        .where('status', isEqualTo: AttemptStatus.submitted.name)
        .orderBy('submittedAt');
    return q.snapshots().map((s) {
      final all = s.docs.map(TestAttempt.fromFirestore).toList();
      if (subject == null || subject.isEmpty) return all;
      return all.where((a) => a.subject == subject).toList();
    });
  }
}
