// ─────────────────────────────────────────────────────────
// UPDATE — merge into lib/widgets/widgets.dart
// Replace the existing UserAvatar class with this version.
// ─────────────────────────────────────────────────────────

class UserAvatar extends StatelessWidget {
  final String initials;
  final double radius;
  final String? photoUrl;
  final AppUser? targetUser; // Add this

  const UserAvatar({
    super.key,
    required this.initials,
    this.radius = 20,
    this.photoUrl,
    this.targetUser,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: targetUser == null ? null : () {
        Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => ProfilePage(user: targetUser!)
        ));
      },
      child: CircleAvatar(
        radius: radius,
        backgroundColor: C.primaryBg,
        backgroundImage: photoUrl != null ? NetworkImage(photoUrl!) : null,
        child: photoUrl == null
          ? Text(initials, style: TextStyle(fontSize: radius * 0.8))
          : null,
      ),
    );
  }
}
