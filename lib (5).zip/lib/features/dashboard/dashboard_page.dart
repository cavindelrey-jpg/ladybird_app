// lib/features/dashboard/dashboard_page.dart
// Redesigned dashboard: animated welcome, role hero, live stats, events, announcements.

import 'package:flutter/material.dart';
import '../../models/models.dart';
import '../../repositories/announcement_repository.dart';
import '../../repositories/calendar_repository.dart';
import '../../theme/app_theme.dart';
import '../../theme/app_colors.dart';
import '../../widgets/widgets.dart';

class DashboardPage extends StatefulWidget {
  final AppUser user;
  const DashboardPage({super.key, required this.user});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: RefreshIndicator(
          onRefresh: () async => setState(() {}),
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(child: _DashHeader(user: widget.user)),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                sliver: SliverList(delegate: SliverChildListDelegate([
                  const SizedBox(height: 20),
                  _HeroBanner(user: widget.user),
                  const SizedBox(height: 24),
                  const SectionHeader(title: 'Upcoming Events'),
                  const SizedBox(height: 10),
                  _LiveEvents(schoolId: widget.user.schoolId),
                  const SizedBox(height: 24),
                  const SectionHeader(title: 'Latest Announcements'),
                  const SizedBox(height: 10),
                  _LiveAnnouncements(schoolId: widget.user.schoolId),
                ])),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Header ────────────────────────────────────────────────

class _DashHeader extends StatelessWidget {
  final AppUser user;
  const _DashHeader({required this.user});

  @override
  Widget build(BuildContext context) {
    final ac = AppColors.of(context);
    final rc = RoleColors.fg(user.role.name);
    return Container(
      color: ac.surf,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      child: Row(children: [
        UserAvatar(initials: user.initials, radius: 24,
            bg: RoleColors.bg(user.role.name), fg: rc),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Welcome back', style: AppText.caption.copyWith(fontSize: 12, color: ac.txt2)),
          const SizedBox(height: 1),
          Text(user.name, style: AppText.h2.copyWith(fontSize: 17),
              overflow: TextOverflow.ellipsis),
        ])),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
              color: RoleColors.bg(user.role.name),
              borderRadius: BorderRadius.circular(Rad.xs),
              border: Border.all(color: rc.withValues(alpha: .16), width: 1)),
          child: Text(user.roleLabel, style: AppText.label.copyWith(
              fontSize: 10.5, letterSpacing: 0.3, color: rc)),
        ),
      ]),
    );
  }
}

// ── Hero Banner ───────────────────────────────────────────

class _HeroBanner extends StatelessWidget {
  final AppUser user;
  const _HeroBanner({required this.user});

  Map<String, dynamic> get _cfg {
    switch (user.role) {
      case UserRole.superAdmin:
        return {
          'title': 'Platform Overview',
          'sub': 'All institutions under your control.',
          'colors': [const Color(0xFF5B21B6), const Color(0xFF7C3AED)],
          'icon': Icons.hub_rounded,
        };
      case UserRole.schoolAdmin:
        return {
          'title': 'School Dashboard',
          'sub': 'Manage users, courses and settings.',
          'colors': [const Color(0xFF15803D), const Color(0xFF16A34A)],
          'icon': Icons.domain_rounded,
        };
      case UserRole.departmentAdmin:
        return {
          'title': 'Department Hub',
          'sub': 'Oversee courses and student progress.',
          'colors': [const Color(0xFF14532D), const Color(0xFF15803D)],
          'icon': Icons.corporate_fare_rounded,
        };
      case UserRole.lecturer:
        return {
          'title': 'Teaching Hub',
          'sub': 'Courses, assignments, marks & attendance.',
          'colors': [const Color(0xFF92400E), const Color(0xFFC9A227)],
          'icon': Icons.cast_for_education_rounded,
        };
      case UserRole.student:
        return {
          'title': 'Your Campus',
          'sub': 'Library, assignments, timetable & results.',
          'colors': [const Color(0xFF166534), const Color(0xFF16A34A)],
          'icon': Icons.school_rounded,
        };
      case UserRole.guest:
        return {
          'title': 'Welcome',
          'sub': 'Explore Green Hills.',
          'colors': [const Color(0xFF334155), const Color(0xFF475569)],
          'icon': Icons.explore_rounded,
        };
    }
  }

  @override
  Widget build(BuildContext context) {
    final cfg = _cfg;
    final String title = cfg['title'];
    final String sub = cfg['sub'];
    final List<Color> colors = cfg['colors'];
    final IconData icon = cfg['icon'];

    return GradientCard(
      colors: colors, height: 120,
      child: Stack(children: [
        Positioned(right: -8, top: -8,
            child: Icon(icon, size: 100, color: Colors.white.withValues(alpha: .1))),
        Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(title, style: AppText.h2.copyWith(fontSize: 16, color: Colors.white)),
                const SizedBox(height: 6),
                Text(sub, style: AppText.bodySm.copyWith(
                    color: Colors.white.withValues(alpha: .8))),
              ]),
        ),
      ]),
    );
  }
}

// ── Live Events ───────────────────────────────────────────

class _LiveEvents extends StatelessWidget {
  final String? schoolId;
  const _LiveEvents({this.schoolId});

  static Color _typeColor(AppColors ac, CalendarEventType t) {
    switch (t) {
      case CalendarEventType.exam:       return ac.red;
      case CalendarEventType.holiday:    return ac.grn;
      case CalendarEventType.classStart: return ac.primary;
      case CalendarEventType.deadline:   return ac.org;
      case CalendarEventType.ceremony:   return ac.gold;
      default:                           return ac.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final ac = AppColors.of(context);
    if (schoolId == null || schoolId!.isEmpty) {
      return const EmptyState(icon: Icons.event_outlined, title: 'No events scheduled',
          subtitle: 'Upcoming events will appear here');
    }
    return StreamBuilder<List<CalendarEvent>>(
      stream: CalendarRepository.instance.watchUpcoming(schoolId!)
          .map((l) => l.take(3).toList()),
      builder: (ctx, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Column(children: [
            ShimmerCard(height: 64), ShimmerCard(height: 64)]);
        }
        if (snap.hasError) return ErrorView(message: snap.error.toString());
        final events = snap.data ?? [];
        if (events.isEmpty) {
          return const EmptyState(icon: Icons.event_outlined, title: 'No upcoming events');
        }
        return Column(children: events.map((e) {
          final col = _typeColor(ac, e.type);
          return ACard(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Container(width: 46, height: 46,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: col.withValues(alpha: .1),
                      borderRadius: BorderRadius.circular(Rad.sm),
                      border: Border.all(color: col.withValues(alpha: .14), width: 1)),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('${e.startDate.day}', style: AppText.h2.copyWith(fontSize: 16, color: col)),
                    Text(_monthAbbr(e.startDate.month),
                        style: AppText.label.copyWith(fontSize: 9, letterSpacing: 0.2, color: col)),
                  ])),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(e.title, style: AppText.title.copyWith(fontSize: 13),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                StatusBadge(label: e.typeLabel, color: col),
              ])),
            ]),
          );
        }).expand((w) => [w, const SizedBox(height: 8)]).toList()..removeLast());
      },
    );
  }

  static String _monthAbbr(int m) {
    const a = ['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return m >= 1 && m <= 12 ? a[m] : '';
  }
}

// ── Live Announcements ────────────────────────────────────

class _LiveAnnouncements extends StatelessWidget {
  final String? schoolId;
  const _LiveAnnouncements({this.schoolId});

  @override
  Widget build(BuildContext context) {
    final ac = AppColors.of(context);
    return StreamBuilder<List<Announcement>>(
      stream: AnnouncementRepository.instance
          .watchAnnouncements(schoolId: schoolId).map((l) => l.take(3).toList()),
      builder: (ctx, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Column(children: [
            ShimmerCard(height: 90), ShimmerCard(height: 90)]);
        }
        if (snap.hasError) return ErrorView(message: snap.error.toString());
        final list = snap.data ?? [];
        if (list.isEmpty) {
          return const EmptyState(
              icon: Icons.campaign_outlined, title: 'No announcements yet',
              subtitle: 'School notices will appear here');
        }
        return Column(children: list.map((a) {
          final diff = DateTime.now().difference(a.date);
          final dateStr = diff.inDays == 0 ? 'Today'
              : diff.inDays == 1 ? 'Yesterday' : '${diff.inDays}d ago';
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: AnnCard(
              tag: a.tag.isNotEmpty ? a.tag : 'Notice',
              title: a.title, body: a.body, date: dateStr,
              accent: a.urgent ? ac.red : ac.navy2, urgent: a.urgent,
            ),
          );
        }).toList());
      },
    );
  }
}
