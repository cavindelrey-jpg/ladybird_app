// lib/main.dart
// Green Hills entry point.
// Initialises Firebase, remote config, and analytics before painting a frame.

import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_quill/flutter_quill.dart' show FlutterQuillLocalizations;
import 'package:provider/provider.dart';
import 'theme/app_theme.dart';
import 'theme/app_colors.dart';
import 'providers/theme_provider.dart';
import 'screens/app_router.dart';
import 'services/analytics_service.dart';
import 'services/config_service.dart';
import 'config/branding.dart';

Future<void> main() async {
  // runZonedGuarded catches errors that occur outside Flutter's own build/
  // layout/paint pipeline (async gaps, timers, stream callbacks) — those
  // never reach FlutterError.onError on their own, so without this they'd
  // silently vanish from Crashlytics entirely.
  await runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();

    // Global error boundary — catches widget build errors in release so a
    // crashing subtree shows a visible fallback instead of going blank/black.
    // Set once here rather than in MaterialApp's builder (which reruns on
    // every rebuild of the app).
    ErrorWidget.builder = (details) => _ErrorFallback(details: details);

    // Firebase init
await Firebase.initializeApp(); // Ensure no secrets in client bundle

    // Route Flutter framework errors (build/layout/paint) to Crashlytics as
    // fatal, instead of just printing to console and moving on.
    FlutterError.onError = (details) {
      FlutterError.presentError(details);
      FirebaseCrashlytics.instance.recordFlutterFatalError(details);
    };

    // Remote config (non-blocking — uses defaults if Firestore is unavailable)
    await ConfigService.instance.initialize();

    // Branding (which product this build is: Green Hills platform or a
    // school white-label like Green Hill) — must resolve before runApp
    // so the very first frame already has the right name/colors/logo,
    // not a flash of Green Hills defaults. Falls back to Green Hills on any
    // load failure rather than blocking startup (see branding.dart).
    await Branding.load();

    // Status bar style
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ));

    // Lock to portrait on phones; allow landscape on tablets
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    runApp(const GreenHillsApp());
  }, (error, stack) {
    // Anything not caught above (async errors, isolate-level) lands here.
    FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
  });
}

class GreenHillsApp extends StatelessWidget {
  const GreenHillsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // Was scaffolded (state, prefs persistence, toggle()/setMode()) but
        // never actually registered in the widget tree, and MaterialApp
        // below had no darkTheme/themeMode — so toggling it did nothing.
        // Registering it here and wiring it into MaterialApp is the fix.
        ChangeNotifierProvider(create: (_) => ThemeProvider()..restoreFromPrefs()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, _) => MaterialApp(
          title: Branding.current.appName,
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light.copyWith(
            pageTransitionsTheme: const PageTransitionsTheme(builders: {
              TargetPlatform.android: _GreenHillsPageTransition(),
              TargetPlatform.iOS: _GreenHillsPageTransition(),
            }),
          ),
          darkTheme: AppTheme.dark.copyWith(
            pageTransitionsTheme: const PageTransitionsTheme(builders: {
              TargetPlatform.android: _GreenHillsPageTransition(),
              TargetPlatform.iOS: _GreenHillsPageTransition(),
            }),
          ),
          themeMode: themeProvider.mode,
          home: const _MaintenanceGate(),
          // Missing entirely before this fix — flutter_quill's toolbar
          // buttons (used in both the Article and Course composers) call
          // FlutterQuillLocalizations.of(context) internally, and throw an
          // UnimplementedError the instant they try to build without this
          // delegate registered. That's what made "Write a Post" and
          // "Create Course" appear to do nothing: the push happened, but
          // the composer's toolbar threw on its very first frame, in a
          // tight repeating loop, so the screen never finished rendering.
          localizationsDelegates: const [
            FlutterQuillLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          // Was pinned to a single supported locale, which made following
          // the device's system language structurally impossible — with
          // only one entry in supportedLocales, Flutter's default
          // resolution always resolves to it regardless of what the OS
          // reports. English + French (Cameroon's two official languages)
          // lets Flutter's own built-in widgets (Material/Cupertino date
          // pickers, text-selection toolbar, dialog OK/Cancel, the Quill
          // editor toolbar) actually switch with the system language.
          // App-authored screen text is still hardcoded English throughout
          // — real localization of that copy (arb files + wrapping every
          // string site) is a separate, much larger pass, not attempted
          // here. No locale: override and no localeResolutionCallback
          // override means MaterialApp's default resolution (best match
          // against the device's locale list, falling back to the first
          // supported locale) is what actually does the "follow system
          // language" work.
          supportedLocales: const [Locale('en'), Locale('fr')],
          builder: (ctx, child) => child ?? const SizedBox.shrink(),
        ),
      ),
    );
  }
}

/// Shows a maintenance screen if ConfigService.isMaintenanceMode is true.
class _MaintenanceGate extends StatelessWidget {
  const _MaintenanceGate();

  @override
  Widget build(BuildContext context) {
    if (ConfigService.instance.isMaintenanceMode) {
      return _MaintenanceScreen(
          message: ConfigService.instance.maintenanceMessage);
    }
    return const AppRouter();
  }
}

class _MaintenanceScreen extends StatelessWidget {
  final String message;
  const _MaintenanceScreen({required this.message});

  @override
  Widget build(BuildContext context) {
    final ac = AppColors.of(context);
    return Scaffold(
      backgroundColor: ac.navy,
      body: SafeArea(child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.construction_rounded, size: 64, color: ac.gold),
            const SizedBox(height: 20),
            const Text('Under Maintenance',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700,
                    color: Colors.white)),
            const SizedBox(height: 12),
            Text(message,
                style: const TextStyle(fontSize: 13, color: Colors.white60),
                textAlign: TextAlign.center),
          ]),
        ),
      )),
    );
  }
}

/// A single, consistent motion for every screen transition in the app —
/// a subtle fade combined with a short upward slide, eased out rather than
/// linear. Replaces the stock OS default (which differs per platform and
/// doesn't carry any of the app's own character) with one deliberate,
/// branded feel used everywhere.
class _GreenHillsPageTransition extends PageTransitionsBuilder {
  const _GreenHillsPageTransition();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
    return FadeTransition(
      opacity: curved,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.04),
          end: Offset.zero,
        ).animate(curved),
        child: child,
      ),
    );
  }
}

class _ErrorFallback extends StatelessWidget {
  final FlutterErrorDetails details;
  const _ErrorFallback({required this.details});

  @override
  Widget build(BuildContext context) {
    AnalyticsService.instance.track(GreenHillsEvent.pageViewed,
        params: {'error': details.exception.toString()});
    final ac = AppColors.of(context);
    return Scaffold(
      backgroundColor: ac.bg,
      body: Center(child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 72, height: 72,
            decoration: BoxDecoration(color: ac.redBg,
                borderRadius: BorderRadius.circular(Rad.xl)),
            child: Icon(Icons.error_outline_rounded, size: 36, color: ac.red)),
          const SizedBox(height: 16),
          Text('An unexpected error occurred',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: ac.txt)),
          const SizedBox(height: 8),
          Text(details.exception.toString(),
              style: TextStyle(fontSize: 12, color: ac.txt2),
              textAlign: TextAlign.center, maxLines: 3,
              overflow: TextOverflow.ellipsis),
        ]),
      )),
    );
  }
}
