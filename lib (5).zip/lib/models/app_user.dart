// lib/models/app_user.dart
// 6-tier role system. Fully backward-compatible with prior 4-role enum.

import 'entitlement.dart';

enum UserRole {
  guest,          // unauthenticated / restricted
  student,        // enrolled student
  lecturer,       // course instructor (replaces "teacher")
  departmentAdmin,// dept-level management
  schoolAdmin,    // institution-wide admin
  superAdmin,     // platform owner
}

enum AccountType  { independent, linked, guest }
enum AccountStatus{ active, suspended, assigned, unassigned }

/// Editable education levels shown on Profile — Cameroon GCE-relevant,
/// plus generic options for independent/adult users.
class EducationLevels {
  EducationLevels._();
  static const List<String> all = [
    'Form 1', 'Form 2', 'Form 3', 'Form 4', 'Form 5',
    'Lower Sixth Arts', 'Lower Sixth Science',
    'Upper Sixth Arts', 'Upper Sixth Science',
    'University', 'Professional / Working Adult',
    'Independent Learner', 'Other',
  ];
}

class AppUser {
  final String id;
  final String name;
  final String email;
  final String? photoUrl;
  final UserRole role;
  final String roleName;
  final AccountType accountType;
  final AccountStatus status;
  final String? schoolId;

  /// The enrollment serial number this account was created with, if any.
  /// Kept for record-keeping / support (e.g. "which seat is this student
  /// occupying") — the claim itself is already permanently recorded on the
  /// SerialNumber doc, this is just a convenient back-reference on the user.
  final String? serialNumber;
  final String? departmentId;
  final String classLevel;
  final String? subject;
  final List<String> courseIds;   // courses enrolled / taught
  final bool isFirstLogin;
  final bool adminAccessRevoked;

  /// production_plan.md §8 — the account's access grant.
  ///
  /// This REPLACES the old flat `isPremium` bool as the source of truth.
  /// `isPremium` still exists below as a derived getter, so every existing
  /// caller (AcademicContentPage's premium-resource gate, XpRepository's
  /// unlock checks) keeps working unchanged — the flat bool was never the
  /// concept, just the cheapest possible encoding of it.
  final Entitlement entitlement;

  /// The raw pre-§8 `isPremium` field as stored on the document.
  ///
  /// Kept ONLY so accounts written before the entitlement model existed
  /// don't lose premium access. Read [isPremium] instead — never this.
  /// Once every user doc has been rewritten with entitlement fields (any
  /// profile save does it), this can be dropped.
  final bool legacyIsPremium;

  /// Free-text bio, ~100 words enforced at the Profile edit UI layer.
  final String bio;

  /// User-editable education level (Form 1 .. University .. Independent
  /// Learner). Free text, not tied to classLevel (which is school-scoped).
  final String educationLevel;

  /// Subjects the user has flagged as favorites in Profile settings —
  /// production_plan.md §5's personalization signal, feeds contextual
  /// recommendations (Library/Courses/Magazine/Quizzes surfacing
  /// favorite-subject content first). Values are drawn from
  /// kAcademicSubjects (see academic_content.dart) for consistency with
  /// every other subject picker in the app.
  final List<String> favoriteSubjects;

  /// Per-feature tap counts — kept for potential future usage-ranked
  /// surfaces; Quick Access itself is now a fixed set (see Home).
  final Map<String, int> quickAccessUsage;

  // ── Gamification (real, minimal — no fabricated numbers) ──────────────
  /// Total XP earned — only incremented through a decided XP source
  /// (quiz answers, magazine reads, daily challenge).
  final int xpTotal;

  /// Consecutive days the app has been opened. Recomputed by
  /// AuthService.recordDailyActivity() on each Home page load.
  final int streakDays;

  /// yyyy-MM-dd of the last recorded activity — decides whether today
  /// continues, resets, or is a no-op for the streak.
  final String? lastActiveDate;

  /// yyyy-MM-dd dates active THIS calendar week (Mon–Sun), trimmed weekly —
  /// drives the real M/T/W/T/F/S/S dots on Home.
  final List<String> weekActivityDates;

  // ── Continue Reading (real, minimal — see content_viewer_page.dart) ────
  final String? continueReadingItemId;
  final String? continueReadingTitle;
  final int continueReadingPage;
  final int? continueReadingTotalPages;

  const AppUser({
    required this.id,
    required this.name,
    this.email = '',
    this.photoUrl,
    this.role = UserRole.student,
    this.roleName = '',
    this.accountType = AccountType.independent,
    this.status = AccountStatus.active,
    this.schoolId,
    this.serialNumber,
    this.departmentId,
    this.classLevel = '',
    this.subject,
    this.courseIds = const [],
    this.isFirstLogin = false,
    this.adminAccessRevoked = false,
    this.entitlement = const Entitlement.free(),
    bool isPremium = false,
    this.bio = '',
    this.educationLevel = '',
    this.favoriteSubjects = const [],
    this.quickAccessUsage = const {},
    this.xpTotal = 0,
    this.streakDays = 0,
    this.lastActiveDate,
    this.weekActivityDates = const [],
    this.continueReadingItemId,
    this.continueReadingTitle,
    this.continueReadingPage = 1,
    this.continueReadingTotalPages,
  }) : legacyIsPremium = isPremium;

  // ── Entitlement (production_plan.md §8) ────────────────────────────────────
  /// Whether this account currently has premium access, for ANY reason.
  ///
  /// Derived, not stored — this is the compatibility shim that let §8 land
  /// without touching the call sites that gate premium content
  /// (`academic_content_page.dart`, `xp_repository.dart`). Self-purchased, gifted,
  /// sponsored and admin-granted premium all read `true` here, which is
  /// correct: consumers of this getter care about ACCESS, not about which
  /// of §9's funding paths paid for it. Code that needs to distinguish
  /// them (e.g. the Profile membership row) reads [entitlement] directly.
  ///
  /// The `legacyIsPremium` arm covers accounts stored before the
  /// entitlement fields existed — see that field's doc comment.
  bool get isPremium => entitlement.isActive || legacyIsPremium;

  /// True only for §9's Gifted Premium — premium paid for by someone else.
  bool get isGiftedPremium =>
      entitlement.isActive && entitlement.source == EntitlementSource.gift;

  /// Premium Silver: every premium feature except Video Courses.
  bool get isSilver => entitlement.isSilver && entitlement.isActive;

  /// Premium Gold: full access, including Video Courses.
  bool get isGold => entitlement.isGold && entitlement.isActive;

  /// The single authoritative check for Video Course access — see
  /// core/feature_access.dart#AppFeature.coursesVideoLessons.
  bool get hasVideoCourseAccess => entitlement.includesVideoCourses;

  /// 'Free' / 'Premium' / 'Gifted Premium' — the three states §8 names.
  String get entitlementLabel =>
      entitlement.isActive || !legacyIsPremium ? entitlement.label : 'Premium';

  // ── Identity helpers ───────────────────────────────────────────────────────
  String get uid => id;

  String get initials {
    final parts = name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty);
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts.first[0].toUpperCase();
    return (parts.first[0] + parts.last[0]).toUpperCase();
  }

  String get roleLabel {
    if (roleName.isNotEmpty) return roleName;
    switch (role) {
      case UserRole.guest:           return 'Guest';
      case UserRole.student:         return 'Student';
      case UserRole.lecturer:        return 'Lecturer';
      case UserRole.departmentAdmin: return 'Department Admin';
      case UserRole.schoolAdmin:     return 'School Admin';
      case UserRole.superAdmin:      return 'Super Admin';
    }
  }

  String get accountTypeLabel {
    switch (accountType) {
      case AccountType.independent: return 'Independent';
      case AccountType.linked:      return 'School-Linked';
      case AccountType.guest:       return 'Guest';
    }
  }

  // ── Role booleans ──────────────────────────────────────────────────────────
  bool get isGuest          => role == UserRole.guest || id.isEmpty;
  bool get isStudent        => role == UserRole.student;
  bool get isLecturer       => role == UserRole.lecturer;
  bool get isDeptAdmin      => role == UserRole.departmentAdmin;
  bool get isSchoolAdmin    => role == UserRole.schoolAdmin;
  bool get isSuperAdmin     => role == UserRole.superAdmin;

  // Backward-compat aliases used by existing code
  bool get isTeacher => isLecturer;
  bool get isAdmin   => isDeptAdmin || isSchoolAdmin || isSuperAdmin;
  bool get isParent  => false; // removed from hierarchy; safe fallback

  // ── Privilege system ───────────────────────────────────────────────────────
  int get privilegeLevel {
    switch (role) {
      case UserRole.guest:           return 0;
      case UserRole.student:         return 1;
      case UserRole.lecturer:        return 2;
      case UserRole.departmentAdmin: return 3;
      case UserRole.schoolAdmin:     return 4;
      case UserRole.superAdmin:      return 5;
    }
  }

  static int _level(UserRole r) {
    const m = {
      UserRole.guest: 0, UserRole.student: 1, UserRole.lecturer: 2,
      UserRole.departmentAdmin: 3, UserRole.schoolAdmin: 4, UserRole.superAdmin: 5,
    };
    return m[r] ?? 0;
  }

  bool hasMinRole(UserRole min) => privilegeLevel >= _level(min);

  // ── Permission gates ───────────────────────────────────────────────────────
  bool get canUploadContent    => hasMinRole(UserRole.lecturer);
  bool get canPostAnnouncement => hasMinRole(UserRole.lecturer);
  bool get canManageUsers      => hasMinRole(UserRole.departmentAdmin);
  bool get canManageSchool     => hasMinRole(UserRole.schoolAdmin);
  bool get canManagePlatform   => isSuperAdmin;

  // ── Firestore ──────────────────────────────────────────────────────────────
  /// Lightweight placeholder passed to pages that require a non-null
  /// AppUser (e.g. AcademicContentPage) when a guest is browsing read-only content.
  /// Never written to Firestore, never treated as a real account — id
  /// stays empty so any accidental write attempt is a visible no-op
  /// (AuthService methods already early-return on empty id).
  factory AppUser.guest() => const AppUser(id: '', name: 'Guest');

  factory AppUser.fromFirestore(String id, Map<String, dynamic> d) => AppUser(
    id: id,
    name: d['name'] ?? '',
    email: d['email'] ?? '',
    photoUrl: d['photoUrl'],
    role: _parseRole(d['role']),
    roleName: d['roleName'] ?? '',
    accountType: AccountType.values.firstWhere(
        (a) => a.name == d['accountType'], orElse: () => AccountType.independent),
    status: AccountStatus.values.firstWhere(
        (s) => s.name == d['status'], orElse: () => AccountStatus.active),
    schoolId: d['schoolId'],
    serialNumber: d['serialNumber'],
    departmentId: d['departmentId'],
    classLevel: d['classLevel'] ?? '',
    subject: d['subject'],
    courseIds: List<String>.from(d['courseIds'] ?? []),
    isFirstLogin: d['isFirstLogin'] ?? false,
    adminAccessRevoked: d['adminAccessRevoked'] ?? false,
    isPremium: d['isPremium'] ?? false,
    entitlement: Entitlement.fromUserMap(d,
        legacyIsPremium: d['isPremium'] ?? false),
    bio: d['bio'] ?? '',
    educationLevel: d['educationLevel'] ?? '',
    favoriteSubjects: List<String>.from(d['favoriteSubjects'] ?? []),
    quickAccessUsage: Map<String, int>.from(d['quickAccessUsage'] ?? {}),
    xpTotal: (d['xpTotal'] as num?)?.toInt() ?? 0,
    streakDays: (d['streakDays'] as num?)?.toInt() ?? 0,
    lastActiveDate: d['lastActiveDate'],
    weekActivityDates: List<String>.from(d['weekActivityDates'] ?? []),
    continueReadingItemId: d['continueReadingItemId'],
    continueReadingTitle: d['continueReadingTitle'],
    continueReadingPage: (d['continueReadingPage'] as num?)?.toInt() ?? 1,
    continueReadingTotalPages: (d['continueReadingTotalPages'] as num?)?.toInt(),
  );

  /// Handles both old 4-role values and new 6-role values stored in Firestore.
  static UserRole _parseRole(dynamic raw) {
    final s = raw?.toString() ?? '';
    // old values → new mapping
    if (s == 'teacher') return UserRole.lecturer;
    if (s == 'admin')   return UserRole.schoolAdmin;
    if (s == 'parent')  return UserRole.guest;
    return UserRole.values.firstWhere((r) => r.name == s,
        orElse: () => UserRole.student);
  }

  Map<String, dynamic> toFirestore() => {
    'name': name, 'email': email, 'photoUrl': photoUrl,
    'role': role.name, 'roleName': roleName,
    'accountType': accountType.name, 'status': status.name,
    'schoolId': schoolId, 'serialNumber': serialNumber, 'departmentId': departmentId,
    'classLevel': classLevel, 'subject': subject,
    'courseIds': courseIds,
    'isFirstLogin': isFirstLogin,
    'adminAccessRevoked': adminAccessRevoked,
    // Written as the DERIVED value, so the legacy field stays a truthful
    // mirror of the entitlement for anything still reading it (older app
    // builds in the wild, the firestore.rules premium checks, exports).
    // The entitlement fields below are the source of truth.
    'isPremium': isPremium,
    ...entitlement.toUserMap(),
    'bio': bio,
    'educationLevel': educationLevel,
    'favoriteSubjects': favoriteSubjects,
    'quickAccessUsage': quickAccessUsage,
    'xpTotal': xpTotal,
    'streakDays': streakDays,
    'lastActiveDate': lastActiveDate,
    'weekActivityDates': weekActivityDates,
    'continueReadingItemId': continueReadingItemId,
    'continueReadingTitle': continueReadingTitle,
    'continueReadingPage': continueReadingPage,
    'continueReadingTotalPages': continueReadingTotalPages,
  };

  AppUser copyWith({
    String? id, String? name, String? email, String? photoUrl,
    UserRole? role, String? roleName,
    AccountType? accountType, AccountStatus? status,
    String? schoolId, String? serialNumber, String? departmentId,
    String? classLevel, String? subject, List<String>? courseIds,
    bool? isFirstLogin, bool? adminAccessRevoked, bool? isPremium,
    Entitlement? entitlement,
    String? bio, String? educationLevel, List<String>? favoriteSubjects,
    Map<String, int>? quickAccessUsage,
    int? xpTotal, int? streakDays, String? lastActiveDate,
    List<String>? weekActivityDates,
    String? continueReadingItemId, String? continueReadingTitle,
    int? continueReadingPage, int? continueReadingTotalPages,
  }) => AppUser(
    id: id ?? this.id, name: name ?? this.name,
    email: email ?? this.email, photoUrl: photoUrl ?? this.photoUrl,
    role: role ?? this.role, roleName: roleName ?? this.roleName,
    accountType: accountType ?? this.accountType,
    status: status ?? this.status,
    schoolId: schoolId ?? this.schoolId,
    serialNumber: serialNumber ?? this.serialNumber,
    departmentId: departmentId ?? this.departmentId,
    classLevel: classLevel ?? this.classLevel,
    subject: subject ?? this.subject,
    courseIds: courseIds ?? this.courseIds,
    isFirstLogin: isFirstLogin ?? this.isFirstLogin,
    adminAccessRevoked: adminAccessRevoked ?? this.adminAccessRevoked,
    isPremium: isPremium ?? legacyIsPremium,
    entitlement: entitlement ?? this.entitlement,
    bio: bio ?? this.bio,
    educationLevel: educationLevel ?? this.educationLevel,
    favoriteSubjects: favoriteSubjects ?? this.favoriteSubjects,
    quickAccessUsage: quickAccessUsage ?? this.quickAccessUsage,
    xpTotal: xpTotal ?? this.xpTotal,
    streakDays: streakDays ?? this.streakDays,
    lastActiveDate: lastActiveDate ?? this.lastActiveDate,
    weekActivityDates: weekActivityDates ?? this.weekActivityDates,
    continueReadingItemId: continueReadingItemId ?? this.continueReadingItemId,
    continueReadingTitle: continueReadingTitle ?? this.continueReadingTitle,
    continueReadingPage: continueReadingPage ?? this.continueReadingPage,
    continueReadingTotalPages: continueReadingTotalPages ?? this.continueReadingTotalPages,
  );
}
